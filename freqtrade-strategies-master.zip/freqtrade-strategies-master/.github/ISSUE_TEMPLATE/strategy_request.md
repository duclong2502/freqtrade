---
name: Strategy request
about: Request a strategy
title: ''
labels: "Strategy Request"
assignees: ''

---

*For requestion a new strategy. Please use the template below.*  
*Any strategy request that does not follow the template will be closed.*

## Step 1: What indicators are required?

*Please list all the indicators required for the buy and sell strategy.*

## Step 2: Explain the Buy Strategy

*Please explain in details the indicators you need to run the buy strategy, then
explain in detail what is the trigger to buy.*

## Step 1: Explain the Sell Strategy

*Please explain in details the indicators you need to run the sell strategy, then
explain in detail what is the trigger to sell.*

## Source

What come from this strategy? Cite your source:
* https://
