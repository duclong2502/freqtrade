Thank you for sending your pull request.

## Summary

Explain in one sentence the goal of this PR / Strategy

Solve the issue: #___

## Quick strategy idea

- <change log 1>
- <change log 2>
