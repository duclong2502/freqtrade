# MultiMA_TSL

## Important note!!! This strategy is developed and tested using BUSD pairs' data. So it might give better result if it's being used when BUSD is used as the stake, compared to other stake.

Strategy for Freqtrade https://github.com/freqtrade/freqtrade

This strategy based on SMAOffsetProtectOptV1 (modded by Perkmeister), based on @Lamborghini Store's SMAOffsetProtect strat, heavily based on @tirail's original SMAOffset

Config files that I'm using on my live bot also can be found in the user_data folder.
